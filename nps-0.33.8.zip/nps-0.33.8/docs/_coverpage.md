![logo](https://cdn.jsdelivr.net/gh/djylb/nps/docs/logo.svg)

# NPS <small>0.33.8</small>

> 一款轻量级、高性能、功能强大的内网穿透代理服务器

- 开源、免费、持续更新
- 几乎支持所有协议
- 支持内网HTTP/HTTPS代理、内网Socks5代理、P2P等
- 简洁且功能强大的Web管理界面
- 支持服务端、客户端同时控制
- 扩展功能强大
- 全平台兼容，一键注册为服务

[GitHub](https://github.com/djylb/nps/)
[开始使用](#nps)
