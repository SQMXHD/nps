# 介绍

可在网页上配置和管理各个TCP、UDP隧道、代理隧道、HTTP/HTTPS转发等，功能强大，操作方便。

![image](https://cdn.jsdelivr.net/gh/djylb/nps/image/web2.png)