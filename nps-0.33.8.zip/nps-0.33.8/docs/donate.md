# 捐助

感谢您对 NPS 项目的支持！

如果您希望获得更快的回复或专属支持，可通过以下方式赞助：

- [微信](https://d-jy.net/api/pay/?type=wechat)
- [支付宝](https://d-jy.net/api/pay/?type=alipay)
- [爱发电](https://afdian.com/a/duanlab)
- [GitHub](https://github.com/sponsors/djylb)

---

> 💡 **仅对赞助或付费用户开放直接联系**

📧 联系邮箱：[duan@d-jy.net](mailto:duan@d-jy.net)

💬 联系作者：[微信 / QQ](https://d-jy.net/api/me/)
